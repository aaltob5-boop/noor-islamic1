# ProGuard rules for Noor Islamic Platform
-keep public class com.noor.islamic.* { *; }
-keep public class com.google.androidbrowserhelper.* { *; }
-dontwarn com.google.androidbrowserhelper.**
