# 🌙 نور — Noor Islamic Platform

[![Build APK](https://github.com/YOUR-USERNAME/noor-islamic/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR-USERNAME/noor-islamic/actions/workflows/build.yml)

## 📱 التطبيق

منصة إسلامية شاملة — قرآن، أذكار، أحاديث، سيرة، مكتبة، قبلة، وأسماء الله الحسنى.

## 🔗 الروابط

| | الرابط |
|---|---|
| **الموقع** | https://al-islam-nour.netlify.app/ |
| **آخر APK** | [Releases](../../releases/latest) |

## 📥 تحميل التطبيق

### الطريقة 1: Google Play (قريباً)

### الطريقة 2: APK مباشر
1. افتح [Releases](../../releases/latest)
2. حمل `noor-release-signed.apk`
3. ثبته على جهازك

### الطريقة 3: PWA (من المتصفح)
1. افتح https://al-islam-nour.netlify.app/ في Chrome
2. اضغط القائمة (⋮) → "Add to Home Screen"

## 🚀 للمطورين

### بناء APK محلياً

```bash
./gradlew assembleDebug
```

### متطلبات
- Android Studio
- JDK 17+
- Android SDK 34

## 📄 الترخيص

MIT License — استخدمه كما تشاء.
